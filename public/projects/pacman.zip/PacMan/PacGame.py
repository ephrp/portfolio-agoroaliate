import pygame
import sys
import random

# =========================================================
# CONFIGURATION GENERALE
# =========================================================

NOIR = (0, 0, 0)
BLANC = (255, 255, 255)
ROUGE = (220, 40, 40)
VERT = (0, 200, 0)
BLEU = (60, 120, 255)
JAUNE = (255, 220, 0)
ORANGE = (255, 165, 0)
ROSE = (255, 80, 120)
VIOLET = (180, 80, 255)
GRIS = (120, 120, 120)

TAILLE_CASE = 40

DROITE = 0
HAUT = 1
GAUCHE = 2
BAS = 3

# murs + obstacles non traversables
# d = porte dynamique (niveau 6)
CASES_MURS = ['-', '|', 'a', 'z', 'q', 's', 'x', 'd']

NB_VIES_DEPART = 5
NB_NIVEAUX_MAX = 7  # Levels 1 → 7

# =========================================================
# CHARGEMENT DES IMAGES
# =========================================================

def charger_images():
    ico_pacman = []
    for i in range(10, 111, 5):
        ico_pacman.append(
            pygame.transform.scale(
                pygame.image.load("Ico/Pacman" + str(i) + ".png"),
                (36, 36)
            )
        )
    for i in range(105, 10, -5):
        ico_pacman.append(
            pygame.transform.scale(
                pygame.image.load("Ico/Pacman" + str(i) + ".png"),
                (36, 36)
            )
        )

    ico_fantomes = []
    for i in range(1, 5):
        ico_fantomes.append(
            pygame.transform.scale(
                pygame.image.load("Ico/Ghost" + str(i) + ".png"),
                (36, 36)
            )
        )

    ico_boss = pygame.transform.scale(
        pygame.image.load("Ico/GhostBoss.png"),
        (36, 36)
    )

    images_cases = {
        "noire": pygame.transform.scale(pygame.image.load("Ico/blacktile.png"), (40, 40)),
        "point": pygame.transform.scale(pygame.image.load("Ico/dottile.png"), (40, 40)),
        "super_point": pygame.transform.scale(pygame.image.load("Ico/pilltile.png"), (40, 40)),
        "mur_h": pygame.transform.scale(pygame.image.load("Ico/ht.png"), (40, 40)),
        "mur_v": pygame.transform.scale(pygame.image.load("Ico/vt.png"), (40, 40)),
        "mur_a": pygame.transform.scale(pygame.image.load("Ico/ta.png"), (40, 40)),
        "mur_z": pygame.transform.scale(pygame.image.load("Ico/tz.png"), (40, 40)),
        "mur_q": pygame.transform.scale(pygame.image.load("Ico/tq.png"), (40, 40)),
        "mur_s": pygame.transform.scale(pygame.image.load("Ico/ts.png"), (40, 40)),
    }

    return ico_pacman, ico_fantomes, ico_boss, images_cases

# =========================================================
# CHARGEMENT ET CREATION DES NIVEAUX
# =========================================================

def lire_carte_base(nom_fichier="Carte0.txt"):
    with open(nom_fichier, "r", encoding="utf-8") as fichier:
        return [list(ligne.rstrip("\n")) for ligne in fichier]

def creer_carte_niveau(niveau):
    if niveau == 1:
        return lire_carte_base("Carte0.txt")
    elif niveau == 2:
        return lire_carte_base("Carte1.txt")
    elif niveau == 3:
        return lire_carte_base("Carte2.txt")
    elif niveau == 4:
        return lire_carte_base("Carte3.txt")
    elif niveau == 5:
        return lire_carte_base("Carte4.txt")
    elif niveau == 6:
        return lire_carte_base("Carte5.txt")
    elif niveau == 7:
        return lire_carte_base("Carte6.txt")
    else:
        return lire_carte_base("Carte0.txt")

# =========================================================
# FONCTIONS UTILITAIRES
# =========================================================

def position_vers_case(x, y):
    return y // TAILLE_CASE, x // TAILLE_CASE

def est_dans_grille(ligne, colonne, matrice):
    return 0 <= ligne < len(matrice) and 0 <= colonne < len(matrice[0])

def mouvement_valide(x, y, matrice):
    ligne, colonne = position_vers_case(x, y)
    if not est_dans_grille(ligne, colonne, matrice):
        return False
    return matrice[ligne][colonne] not in CASES_MURS

def collision(x1, y1, x2, y2):
    return abs(x1 - x2) < 30 and abs(y1 - y2) < 30

def deplacement_direction(x, y, direction, vitesse):
    if direction == DROITE:
        return x + vitesse, y
    if direction == GAUCHE:
        return x - vitesse, y
    if direction == HAUT:
        return x, y - vitesse
    if direction == BAS:
        return x, y + vitesse
    return x, y

def direction_opposee(direction):
    if direction == DROITE:
        return GAUCHE
    if direction == GAUCHE:
        return DROITE
    if direction == HAUT:
        return BAS
    return HAUT

def trouver_case_libre(matrice, case_interdite=None):
    libres = []
    for l in range(len(matrice)):
        for c in range(len(matrice[0])):
            if matrice[l][c] not in CASES_MURS:
                if case_interdite is None or (l, c) != case_interdite:
                    libres.append((l, c))
    return random.choice(libres) if libres else (1, 1)

def trouver_case_depart_pacman(matrice):
    ligne_depart = len(matrice) - 2
    colonne_depart = 1
    if 0 <= ligne_depart < len(matrice) and 0 <= colonne_depart < len(matrice[0]):
        if matrice[ligne_depart][colonne_depart] not in CASES_MURS:
            return (ligne_depart, colonne_depart)

    for ligne in range(len(matrice) - 2, -1, -1):
        for colonne in range(len(matrice[0])):
            if matrice[ligne][colonne] not in CASES_MURS:
                return (ligne, colonne)
    return (1, 1)

def afficher_message_centre(surface, texte, police, couleur, largeur_vue, hauteur_vue, decalage_y=0):
    rendu = police.render(texte, True, couleur)
    rect = rendu.get_rect(center=(largeur_vue // 2, hauteur_vue // 2 + decalage_y))
    surface.blit(rendu, rect)

def reste_objets_a_manger(matrice):
    for ligne in matrice:
        if 'r' in ligne or '.' in ligne or 'o' in ligne:
            return True
    return False

# =========================================================
# AFFICHAGE DE LA CARTE
# =========================================================

def afficher_carte(matrice, surface, images_cases):
    for ligne_index, ligne in enumerate(matrice):
        for colonne_index, case_courante in enumerate(ligne):
            x = colonne_index * TAILLE_CASE
            y = ligne_index * TAILLE_CASE
            position = (x, y)

            if case_courante == '.':
                surface.blit(images_cases["point"], position)
            elif case_courante == 'o':
                surface.blit(images_cases["super_point"], position)
            elif case_courante == 'r':
                pygame.draw.circle(surface, ROUGE, (x + TAILLE_CASE // 2, y + TAILLE_CASE // 2), 6)
            elif case_courante == '-':
                surface.blit(images_cases["mur_h"], position)
            elif case_courante == '|':
                surface.blit(images_cases["mur_v"], position)
            elif case_courante == 'a':
                surface.blit(images_cases["mur_a"], position)
            elif case_courante == 'z':
                surface.blit(images_cases["mur_z"], position)
            elif case_courante == 'q':
                surface.blit(images_cases["mur_q"], position)
            elif case_courante == 's':
                surface.blit(images_cases["mur_s"], position)
            elif case_courante == 'b':  # bonus
                pygame.draw.rect(surface, ORANGE, (x + 8, y + 8, 24, 24))
            elif case_courante == 'v':  # invincibilité
                pygame.draw.rect(surface, VERT, (x + 8, y + 8, 24, 24))
            elif case_courante == 'g':  # mode fantôme
                pygame.draw.rect(surface, BLEU, (x + 8, y + 8, 24, 24))
            elif case_courante == 't':  # téléportation
                pygame.draw.rect(surface, JAUNE, (x + 8, y + 8, 24, 24))
            elif case_courante == 'm':  # malus
                pygame.draw.rect(surface, ROSE, (x + 8, y + 8, 24, 24))
            elif case_courante == 'x':  # obstacle
                pygame.draw.rect(surface, GRIS, (x, y, TAILLE_CASE, TAILLE_CASE))
            elif case_courante == 'd':  # porte dynamique
                pygame.draw.rect(surface, VIOLET, (x + 4, y + 4, 32, 32))
            else:
                surface.blit(images_cases["noire"], position)

# =========================================================
# ECRANS
# =========================================================

def afficher_texte_centre(surface, texte, police, couleur, x, y):
    rendu = police.render(texte, True, couleur)
    rect = rendu.get_rect(center=(x, y))
    surface.blit(rendu, rect)


def choisir_niveau(ecran, largeur_vue, hauteur_vue, police_titre, police_info):
    niveaux = [1, 2, 3, 4, 5, 6, 7]
    index = 0

    while True:
        ecran.fill(NOIR)

        afficher_message_centre(ecran, "CHOIX DU NIVEAU", police_titre, JAUNE, largeur_vue, hauteur_vue, -220)
        afficher_message_centre(ecran, "ENTREE : lancer le niveau", police_info, BLANC, largeur_vue, hauteur_vue, -160)
        afficher_message_centre(ecran, "ECHAP : retour", police_info, BLANC, largeur_vue, hauteur_vue, -130)

        for i, niveau in enumerate(niveaux):
            y = hauteur_vue // 2 - 20 + i * 35

            if i == index:
                pygame.draw.rect(
                    ecran,
                    BLEU,
                    (largeur_vue // 2 - 120, y - 15, 240, 30),
                    border_radius=8
                )
                couleur = JAUNE
            else:
                couleur = BLANC

            afficher_texte_centre(ecran, f"Niveau {niveau}", police_info, couleur, largeur_vue // 2, y)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    index = (index - 1) % len(niveaux)

                elif event.key == pygame.K_DOWN:
                    index = (index + 1) % len(niveaux)

                elif event.key == pygame.K_RETURN:
                    return niveaux[index]

                elif event.key == pygame.K_ESCAPE:
                    return None

def afficher_menu(ecran, largeur_vue, hauteur_vue, police_titre, police_info):
    options = ["JOUER", "CHOISIR NIVEAU", "QUITTER"]
    index = 0
    niveau_selectionne = 1

    while True:
        ecran.fill(NOIR)

        afficher_message_centre(ecran, "MINI PACMAN", police_titre, JAUNE, largeur_vue, hauteur_vue, -160)
        afficher_message_centre(
            ecran,
            f"Niveau sélectionné : {niveau_selectionne}",
            police_info,
            BLANC,
            largeur_vue,
            hauteur_vue,
            -90
        )

        for i, option in enumerate(options):
            y = hauteur_vue // 2 + i * 50

            if i == index:
                pygame.draw.rect(
                    ecran,
                    BLEU,
                    (largeur_vue // 2 - 160, y - 20, 320, 40),
                    border_radius=10
                )
                couleur = JAUNE
            else:
                couleur = BLANC

            afficher_texte_centre(ecran, option, police_info, couleur, largeur_vue // 2, y)

        afficher_message_centre(
            ecran,
            "FLECHES : naviguer | ENTREE : valider",
            police_info,
            GRIS,
            largeur_vue,
            hauteur_vue,
            200
        )

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    index = (index - 1) % len(options)

                elif event.key == pygame.K_DOWN:
                    index = (index + 1) % len(options)

                elif event.key == pygame.K_RETURN:
                    if options[index] == "JOUER":
                        return niveau_selectionne

                    elif options[index] == "CHOISIR NIVEAU":
                        niveau_choisi = choisir_niveau(
                            ecran,
                            largeur_vue,
                            hauteur_vue,
                            police_titre,
                            police_info
                        )

                        if niveau_choisi is not None:
                            return niveau_choisi

                    elif options[index] == "QUITTER":
                        pygame.quit()
                        sys.exit()
def afficher_transition_niveau(ecran, largeur_vue, hauteur_vue, police_titre, police_info, niveau):
    debut = pygame.time.get_ticks()
    while pygame.time.get_ticks() - debut < 1800:
        ecran.fill(NOIR)
        afficher_message_centre(ecran, f"NIVEAU {niveau}", police_titre, JAUNE, largeur_vue, hauteur_vue, -20)
        afficher_message_centre(ecran, "Prépare-toi...", police_info, BLANC, largeur_vue, hauteur_vue, 30)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

def afficher_decompte(ecran, largeur_vue, hauteur_vue, police_titre, police_info, horloge):
    for nombre in ["3", "2", "1", "GO!"]:
        debut = pygame.time.get_ticks()

        while pygame.time.get_ticks() - debut < 900:
            ecran.fill(NOIR)

            afficher_message_centre(
                ecran,
                nombre,
                police_titre,
                JAUNE,
                largeur_vue,
                hauteur_vue,
                -20
            )

            afficher_message_centre(
                ecran,
                "Prépare-toi...",
                police_info,
                BLANC,
                largeur_vue,
                hauteur_vue,
                40
            )

            pygame.display.flip()
            horloge.tick(60)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

def afficher_ecran_fin(ecran, largeur_vue, hauteur_vue, police_titre, police_info, victoire_finale):
    while True:
        ecran.fill(NOIR)

        if victoire_finale:
            afficher_message_centre(ecran, "VICTOIRE FINALE", police_titre, VERT, largeur_vue, hauteur_vue, -50)
        else:
            afficher_message_centre(ecran, "GAME OVER", police_titre, ROUGE, largeur_vue, hauteur_vue, -50)

        afficher_message_centre(ecran, "R : rejouer", police_info, BLANC, largeur_vue, hauteur_vue, 20)
        afficher_message_centre(ecran, "ECHAP : quitter", police_info, BLANC, largeur_vue, hauteur_vue, 55)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return True
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

# =========================================================
# IA DES FANTOMES
# =========================================================

def direction_vers_pacman(fantome, pacman_x, pacman_y, matrice):
    fx, fy = fantome["x"], fantome["y"]
    ligne_f, col_f = position_vers_case(fx, fy)
    ligne_p, col_p = position_vers_case(pacman_x, pacman_y)

    if col_p < col_f:
        tx, ty = fx - fantome["vitesse"], fy
        if mouvement_valide(tx, ty, matrice):
            return GAUCHE
    if col_p > col_f:
        tx, ty = fx + fantome["vitesse"], fy
        if mouvement_valide(tx, ty, matrice):
            return DROITE

    if ligne_p < ligne_f:
        tx, ty = fx, fy - fantome["vitesse"]
        if mouvement_valide(tx, ty, matrice):
            return HAUT
    if ligne_p > ligne_f:
        tx, ty = fx, fy + fantome["vitesse"]
        if mouvement_valide(tx, ty, matrice):
            return BAS

    return fantome["dir"]

def direction_boss(fantome, pacman_x, pacman_y, matrice):
    # IA plus agressive : teste toutes les directions, choisit celle qui réduit le plus la distance
    ligne_p, col_p = position_vers_case(pacman_x, pacman_y)
    meilleures_dirs = []
    meilleur_score = 10**9

    for direction in [DROITE, HAUT, GAUCHE, BAS]:
        test_x, test_y = deplacement_direction(fantome["x"], fantome["y"], direction, fantome["vitesse"])
        if not mouvement_valide(test_x, test_y, matrice):
            continue
        l, c = position_vers_case(test_x, test_y)
        distance = abs(l - ligne_p) + abs(c - col_p)
        if distance < meilleur_score:
            meilleur_score = distance
            meilleures_dirs = [direction]
        elif distance == meilleur_score:
            meilleures_dirs.append(direction)

    if meilleures_dirs:
        return random.choice(meilleures_dirs)
    return fantome["dir"]

def choisir_direction_fantome(fantome, pacman_x, pacman_y, matrice, mode_fuite=False):
    ia = fantome.get("ia", 2)

    if ia == 3 and not mode_fuite:
        return direction_vers_pacman(fantome, pacman_x, pacman_y, matrice)

    if ia == 4 and not mode_fuite:
        return direction_boss(fantome, pacman_x, pacman_y, matrice)

    if ia == 1 and not mode_fuite:
        directions = [DROITE, HAUT, GAUCHE, BAS]
        random.shuffle(directions)
        for d in directions:
            tx, ty = deplacement_direction(fantome["x"], fantome["y"], d, fantome["vitesse"])
            if mouvement_valide(tx, ty, matrice):
                return d
        return fantome["dir"]

    ligne_pacman, colonne_pacman = position_vers_case(pacman_x, pacman_y)
    directions = [DROITE, HAUT, GAUCHE, BAS]
    meilleure_direction = fantome["dir"]

    meilleur_score = -10**9 if mode_fuite else 10**9

    for direction in directions:
        test_x, test_y = deplacement_direction(
            fantome["x"], fantome["y"], direction, fantome["vitesse"]
        )

        if not mouvement_valide(test_x, test_y, matrice):
            continue

        ligne_test, colonne_test = position_vers_case(test_x, test_y)
        distance = abs(ligne_test - ligne_pacman) + abs(colonne_test - colonne_pacman)

        penalite = 1 if direction == direction_opposee(fantome["dir"]) else 0
        score = distance - penalite if mode_fuite else distance + penalite

        if (mode_fuite and score > meilleur_score) or (not mode_fuite and score < meilleur_score):
            meilleur_score = score
            meilleure_direction = direction

    return meilleure_direction

def reinitialiser_fantome(fantome):
    fantome["x"] = fantome["spawn_x"]
    fantome["y"] = fantome["spawn_y"]
    fantome["dir"] = fantome["dir_depart"]
    fantome["compteur_dir"] = 0

# =========================================================
# CREATION DES FANTOMES
# =========================================================

def creer_fantomes_pour_niveau(niveau, matrice):
    hauteur = len(matrice)
    largeur = len(matrice[0])

    nb_fantomes = 4

    fantomes = []
    positions_de_base = [
        (hauteur // 2 - 1, largeur // 2 - 1),
        (hauteur // 2 - 1, largeur // 2 + 1),
        (hauteur // 2 + 1, largeur // 2 - 1),
        (hauteur // 2 + 1, largeur // 2 + 1),
    ]
    directions_depart = [DROITE, GAUCHE, HAUT, BAS]

    for i in range(nb_fantomes):
        l, c = positions_de_base[i]
        if matrice[l][c] in CASES_MURS:
            l, c = trouver_case_libre(matrice)

        if niveau == 1:
            vitesse = 1
            cooldown_dir = 30
            ia = 1
        elif niveau in (2, 3):
            vitesse = 2
            cooldown_dir = 18
            ia = 2
        elif niveau in (4, 5, 6):
            vitesse = 3
            cooldown_dir = 8 if niveau == 5 else 10
            ia = 3
        elif niveau == 7:
            if i == 0:
                vitesse = 6
                cooldown_dir = 4
                ia = 4  # boss
            else:
                vitesse = 5
                cooldown_dir = 7
                ia = 3
        else:
            vitesse = 2
            cooldown_dir = 18
            ia = 2

        fantomes.append({
            "x": c * TAILLE_CASE,
            "y": l * TAILLE_CASE,
            "dir": directions_depart[i],
            "dir_depart": directions_depart[i],
            "spawn_x": c * TAILLE_CASE,
            "spawn_y": l * TAILLE_CASE,
            "vitesse": vitesse,
            "cooldown_dir": cooldown_dir,
            "compteur_dir": 0,
            "ia": ia
        })

    return fantomes

# =========================================================
# BOUCLE D'UN NIVEAU
# =========================================================

def jouer_un_niveau(
    ecran,
    niveau,
    vies_actuelles,
    score_actuel,
    ico_pacman,
    ico_fantomes,
    ico_boss,
    images_cases,
    police_hud,
    police_fin,
    police_info,
    horloge
):
    matrice = creer_carte_niveau(niveau)

    hauteur = len(matrice)
    largeur = len(matrice[0])
    vue_largeur = largeur * TAILLE_CASE
    vue_hauteur = hauteur * TAILLE_CASE

    ecran = pygame.display.set_mode((vue_largeur, vue_hauteur))
    pygame.display.set_caption(f"Mini Pacman - Niveau {niveau}")

    case_depart = trouver_case_depart_pacman(matrice)

    pacman_x = case_depart[1] * TAILLE_CASE
    pacman_y = case_depart[0] * TAILLE_CASE
    direction_pacman = DROITE
    prochaine_direction = DROITE
    animation_pacman = 0

    fantomes = creer_fantomes_pour_niveau(niveau, matrice)

    etat = {
        "score": score_actuel,
        "vies": vies_actuelles,
        "deplacements": 0,
        "super_mode_deplacements": 0,
        "fantomes_manges": 0,
        "invincible": 0,
        "fantome_mode": 0,
    }

    jeu_actif = True
    resultat = None

    if niveau == 1:
        temps_respawn = 0
        fantomes_bloques_timer = 0
    else:
        temps_respawn = 40
        fantomes_bloques_timer = 180

    # Niveau 6 : portes dynamiques
    portes_dynamiques = []
    portes_ouvertes = False
    timer_portes = 0
    duree_cycle_portes = 90  # frames

    if niveau == 6:
        for l in range(hauteur):
            for c in range(largeur):
                if matrice[l][c] == 'd':
                    portes_dynamiques.append((l, c))

    afficher_decompte(
        ecran,
        vue_largeur,
        vue_hauteur,
        police_fin,
        police_info,
        horloge
    )

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if jeu_actif and event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    prochaine_direction = GAUCHE
                elif event.key == pygame.K_RIGHT:
                    prochaine_direction = DROITE
                elif event.key == pygame.K_UP:
                    prochaine_direction = HAUT
                elif event.key == pygame.K_DOWN:
                    prochaine_direction = BAS

        if jeu_actif:
            vitesse_pacman = 2 if niveau < 4 else 3

            if etat["fantome_mode"] > 0:
                direction_pacman = prochaine_direction
            else:
                test_x, test_y = deplacement_direction(
                    pacman_x, pacman_y, prochaine_direction, vitesse_pacman
                )
                if mouvement_valide(test_x, test_y, matrice):
                    direction_pacman = prochaine_direction

            nouveau_x, nouveau_y = deplacement_direction(
                pacman_x, pacman_y, direction_pacman, vitesse_pacman
            )

            ancienne_case = position_vers_case(pacman_x, pacman_y)

            if etat["fantome_mode"] > 0 or mouvement_valide(nouveau_x, nouveau_y, matrice):
                pacman_x = nouveau_x
                pacman_y = nouveau_y
                nouvelle_case = position_vers_case(pacman_x, pacman_y)

                if nouvelle_case != ancienne_case:
                    etat["deplacements"] += 1

                    if niveau == 1 and etat["deplacements"] >= 20:
                        jeu_actif = False
                        resultat = "VICTOIRE"

                    if niveau >= 2 and etat["super_mode_deplacements"] > 0:
                        etat["super_mode_deplacements"] -= 1

                    if etat["invincible"] > 0:
                        etat["invincible"] -= 1
                    if etat["fantome_mode"] > 0:
                        etat["fantome_mode"] -= 1

            # Niveau 6 : gestion des portes dynamiques
            if niveau == 6 and portes_dynamiques:
                timer_portes += 1
                if timer_portes >= duree_cycle_portes:
                    timer_portes = 0
                    portes_ouvertes = not portes_ouvertes
                    for (l, c) in portes_dynamiques:
                        matrice[l][c] = ' ' if portes_ouvertes else 'd'

            ligne_pac, col_pac = position_vers_case(pacman_x, pacman_y)
            case = matrice[ligne_pac][col_pac]

            if niveau >= 2:
                if case == 'r':
                    etat["score"] += 200
                    matrice[ligne_pac][col_pac] = ' '
                    etat["super_mode_deplacements"] = 10
                    case = ' '
                elif case == '.':
                    etat["score"] += 10
                    matrice[ligne_pac][col_pac] = ' '
                    case = ' '

            if niveau == 5 or niveau == 6 or niveau == 7:
                if case == 'b':
                    etat["score"] += 500
                    matrice[ligne_pac][col_pac] = ' '
                elif case == 'v':
                    etat["invincible"] = 20
                    matrice[ligne_pac][col_pac] = ' '
                elif case == 'g':
                    etat["fantome_mode"] = 15
                    matrice[ligne_pac][col_pac] = ' '
                elif case == 't':
                    l, c = trouver_case_libre(matrice)
                    pacman_x = c * TAILLE_CASE
                    pacman_y = l * TAILLE_CASE
                    matrice[ligne_pac][col_pac] = ' '
                elif case == 'm':
                    etat["score"] -= 200
                    matrice[ligne_pac][col_pac] = ' '

            for fantome in fantomes:
                if fantomes_bloques_timer > 0:
                    continue

                if fantome["compteur_dir"] <= 0:
                    mode_fuite = etat["super_mode_deplacements"] > 0
                    nouvelle_direction = choisir_direction_fantome(
                        fantome, pacman_x, pacman_y, matrice, mode_fuite
                    )
                    fantome["dir"] = nouvelle_direction
                    fantome["compteur_dir"] = fantome["cooldown_dir"]
                else:
                    fantome["compteur_dir"] -= 1

                fantome_x, fantome_y = deplacement_direction(
                    fantome["x"], fantome["y"], fantome["dir"], fantome["vitesse"]
                )

                if mouvement_valide(fantome_x, fantome_y, matrice):
                    fantome["x"] = fantome_x
                    fantome["y"] = fantome_y

            for fantome in fantomes:
                if collision(pacman_x, pacman_y, fantome["x"], fantome["y"]):

                    if etat["invincible"] > 0 or etat["super_mode_deplacements"] > 0:
                        etat["score"] += 400
                        etat["fantomes_manges"] += 1
                        reinitialiser_fantome(fantome)
                        continue

                    if etat["fantome_mode"] > 0:
                        continue

                    etat["vies"] -= 1

                    if etat["vies"] <= 0:
                        jeu_actif = False
                        resultat = "GAME OVER"
                    else:
                        pacman_x = case_depart[1] * TAILLE_CASE
                        pacman_y = case_depart[0] * TAILLE_CASE
                        direction_pacman = DROITE
                        prochaine_direction = DROITE

                        if niveau == 1:
                            temps_respawn = 0
                            fantomes_bloques_timer = 0
                        else:
                            temps_respawn = 40
                            fantomes_bloques_timer = 120

                        for f in fantomes:
                            reinitialiser_fantome(f)

                    break

            if fantomes_bloques_timer > 0:
                fantomes_bloques_timer -= 1

            if jeu_actif and niveau >= 2:
                plus_de_points = not reste_objets_a_manger(matrice)
                tous_fantomes_manges = etat["fantomes_manges"] >= len(fantomes)

                if plus_de_points or tous_fantomes_manges:
                    jeu_actif = False
                    resultat = "VICTOIRE"

        ecran.fill(NOIR)
        afficher_carte(matrice, ecran, images_cases)

        ecran.blit(ico_pacman[animation_pacman], (pacman_x + 2, pacman_y + 2))

        for i, fantome in enumerate(fantomes):
            if (niveau >= 2 and etat["super_mode_deplacements"] > 0) or etat["invincible"] > 0:
                pygame.draw.circle(
                    ecran,
                    BLEU,
                    (fantome["x"] + TAILLE_CASE // 2, fantome["y"] + TAILLE_CASE // 2),
                    16
                )
                pygame.draw.circle(ecran, BLANC, (fantome["x"] + 14, fantome["y"] + 16), 3)
                pygame.draw.circle(ecran, BLANC, (fantome["x"] + 24, fantome["y"] + 16), 3)
            else:
                if niveau == 7 and i == 0:
                    ecran.blit(ico_boss, (fantome["x"] + 2, fantome["y"] + 2))
                else:
                    ecran.blit(ico_fantomes[i % len(ico_fantomes)], (fantome["x"] + 2, fantome["y"] + 2))

        ecran.blit(police_hud.render(f"Score : {etat['score']}", True, BLANC), (10, 10))
        ecran.blit(police_hud.render(f"Déplacements : {etat['deplacements']}", True, BLANC), (10, 38))
        ecran.blit(police_hud.render(f"Vies : {etat['vies']}", True, BLANC), (10, 66))
        ecran.blit(police_hud.render(f"Niveau : {niveau}", True, BLANC), (10, 94))

        if niveau >= 5:
            txt_inv = f"Invincible : {etat['invincible']}" if etat["invincible"] > 0 else "Invincible : 0"
            txt_ghost = f"Fantôme : {etat['fantome_mode']}" if etat["fantome_mode"] > 0 else "Fantôme : 0"
            ecran.blit(police_hud.render(txt_inv, True, VERT), (10, 122))
            ecran.blit(police_hud.render(txt_ghost, True, BLEU), (10, 150))

            if niveau == 6 and portes_dynamiques:
                txt_portes = "Portes : ouvertes" if portes_ouvertes else "Portes : fermées"
                ecran.blit(police_hud.render(txt_portes, True, VIOLET), (10, 178))

            if niveau == 7:
                ecran.blit(police_hud.render("Boss fantôme actif", True, ROUGE), (10, 178))

        pygame.display.flip()
        horloge.tick(50)

        if not jeu_actif and resultat is not None:
            pygame.time.wait(1300)
            return {
                "resultat": resultat,
                "score": etat["score"],
                "vies": etat["vies"],
                "largeur_vue": vue_largeur,
                "hauteur_vue": vue_hauteur,
                "niveau": niveau
            }

# =========================================================
# FONCTION PRINCIPALE
# =========================================================

def lancer_jeu():
    pygame.init()

    ico_pacman, ico_fantomes, ico_boss, images_cases = charger_images()

    police_hud = pygame.font.SysFont(None, 28)
    police_fin = pygame.font.SysFont(None, 52)
    police_info = pygame.font.SysFont(None, 24)
    police_titre = pygame.font.SysFont(None, 64)

    carte_test = creer_carte_niveau(1)
    largeur_initiale = len(carte_test[0]) * TAILLE_CASE
    hauteur_initiale = len(carte_test) * TAILLE_CASE

    ecran = pygame.display.set_mode((largeur_initiale, hauteur_initiale))
    pygame.display.set_caption("Mini Pacman")
    horloge = pygame.time.Clock()

    while True:
        niveau_depart = afficher_menu(
            ecran,
            largeur_initiale,
            hauteur_initiale,
            police_titre,
            police_info
        )

        score_total = 0
        vies_restantes = NB_VIES_DEPART
        niveau = niveau_depart
        victoire_finale = False

        while niveau <= NB_NIVEAUX_MAX:
            carte_niveau = creer_carte_niveau(niveau)
            largeur_vue = len(carte_niveau[0]) * TAILLE_CASE
            hauteur_vue = len(carte_niveau) * TAILLE_CASE
            ecran = pygame.display.set_mode((largeur_vue, hauteur_vue))

            afficher_transition_niveau(
                ecran,
                largeur_vue,
                hauteur_vue,
                police_titre,
                police_info,
                niveau
            )

            resultat_niveau = jouer_un_niveau(
    ecran=ecran,
    niveau=niveau,
    vies_actuelles=vies_restantes,
    score_actuel=score_total,
    ico_pacman=ico_pacman,
    ico_fantomes=ico_fantomes,
    ico_boss=ico_boss,
    images_cases=images_cases,
    police_hud=police_hud,
    police_fin=police_fin,
    police_info=police_info,
    horloge=horloge
)
            

            score_total = resultat_niveau["score"]
            vies_restantes = resultat_niveau["vies"]

            if resultat_niveau["resultat"] == "GAME OVER":
                victoire_finale = False
                break

            niveau += 1

        if niveau > NB_NIVEAUX_MAX and vies_restantes > 0:
            victoire_finale = True

        largeur_fin = largeur_vue
        hauteur_fin = hauteur_vue
        ecran = pygame.display.set_mode((largeur_fin, hauteur_fin))

        rejouer = afficher_ecran_fin(
            ecran,
            largeur_fin,
            hauteur_fin,
            police_titre,
            police_info,
            victoire_finale
        )

        if not rejouer:
            break

if __name__ == "__main__":
    lancer_jeu()